#!/bin/bash
# Uninstall SensorBarHelper — run with: sudo ./uninstall.sh
set -e

HELPER_DST="/usr/local/bin/SensorBarHelper"
PLIST_DST="/Library/LaunchDaemons/com.ikeybenz.sensorbar.helper.plist"

if [ "$EUID" -ne 0 ]; then
    echo "Error: Run with sudo"
    echo "Usage: sudo ./uninstall.sh"
    exit 1
fi

if launchctl list | grep -q "com.ikeybenz.sensorbar.helper"; then
    echo "Stopping helper..."
    launchctl unload "$PLIST_DST" 2>/dev/null || true
fi

rm -f "$HELPER_DST" "$PLIST_DST"
rm -f /tmp/sensorbar-helper.stdout.log /tmp/sensorbar-helper.stderr.log

echo "✅ SensorBarHelper uninstalled."
