#!/bin/bash
# Install SensorBarHelper — run with: sudo ./install.sh
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
HELPER_DST="/usr/local/bin/SensorBarHelper"
PLIST_DST="/Library/LaunchDaemons/com.ikeybenz.sensorbar.helper.plist"

if [ "$EUID" -ne 0 ]; then
    echo "Error: Run with sudo"
    echo "Usage: sudo ./install.sh"
    exit 1
fi

# Stop existing if running
if launchctl list | grep -q "com.ikeybenz.sensorbar.helper"; then
    echo "Stopping existing helper..."
    launchctl unload "$PLIST_DST" 2>/dev/null || true
fi

echo "Installing SensorBarHelper..."
cp "$DIR/SensorBarHelper" "$HELPER_DST"
chmod 755 "$HELPER_DST"
chown root:wheel "$HELPER_DST"

cp "$DIR/com.ikeybenz.sensorbar.helper.plist" "$PLIST_DST"
chmod 644 "$PLIST_DST"
chown root:wheel "$PLIST_DST"

launchctl load "$PLIST_DST"

echo ""
echo "✅ SensorBarHelper installed and running!"
echo "   Restart SensorBar to see temperature sensors."
